package one;

public class Point extends Shape {

	public Point(int axisx, int axisy) {
		super(axisx, axisy);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Point";
	}

	@Override
	public boolean contains() {
		// TODO Auto-generated method stub
		return false;
	}
	

}
