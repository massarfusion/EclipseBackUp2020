/**
 * 
 */
/**
 * @author 85230
 *
 */
package de_graphic;