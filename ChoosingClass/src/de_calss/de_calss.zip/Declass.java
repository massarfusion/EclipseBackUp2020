package de_calss;

public class Declass {
	String name;
	int hours;
	public String getName() {
		return name;
	}
	public int getHours() {
		return hours;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	
	
	public Declass() {
		super();
	}
	public Declass(String name, int hours) {
		super();
		this.name = name;
		this.hours = hours;
	}
	
	
	
	
	
	
	
	
}
