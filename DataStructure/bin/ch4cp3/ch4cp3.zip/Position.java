package ch4cp3;

public class Position {
	int axisx;
	int axisy;
	public Position(int axisx, int axisy) {
		super();
		this.axisx = axisx;
		this.axisy = axisy;
	}
	public int getAxisx() {
		return axisx;
	}
	public int getAxisy() {
		return axisy;
	}
	public void setAxisx(int axisx) {
		this.axisx = axisx;
	}
	public void setAxisy(int axisy) {
		this.axisy = axisy;
	}
	
}
